package com.example.cabo.tp4.utils

enum class FieldValidation {
    EMAIL_BAD_FORMAT, PASSWORD_NOT_EQUAL, PASSWORD_LENGHT_FAIL, EMPTY, SUCCESS
}
