package com.example.cabo.tp3.model

import java.io.Serializable
import java.util.*

data class User(
    var dni: Long? = 0,
    var dniType: DniType? = DniType.DNI,
    var nombre: String? = "",
    var apellido: String? = "",
    var fechNac: Date? = Date(),
    var sexo: Sexo? = Sexo.MASCULINO,
    var direccion: String? = "",
    var telefono: Long? = 0,
    var ocupacion: String? = "",
    var ingresoMensual: Int? = 0,
    var uuid: String? = null

) : Serializable

enum class DniType {
    DNI, CI, LE, LC
}

enum class Sexo {
    MASCULINO, FEMENINO
}