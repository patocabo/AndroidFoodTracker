package com.example.cabo.tp4.Auth

import com.google.firebase.auth.AuthResult

interface AuthInterface {
    fun signOut()
    fun signIn(email: String, password: String, callback: (Boolean) -> Unit)
    fun createUserWithEmailAndPassword(email: String, password: String, callback: (Boolean) -> Unit)
}